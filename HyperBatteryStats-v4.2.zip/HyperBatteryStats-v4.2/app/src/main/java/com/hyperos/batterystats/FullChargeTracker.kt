package com.hyperos.batterystats

import android.annotation.SuppressLint
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import de.robv.android.xposed.XposedBridge
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicBoolean

data class SotPersistentState(
    val archivedSotMs: Long,
    val checkpointBootCount: Int,
    val checkpointWallMs: Long,
    val checkpointUptimeMs: Long,
    val checkpointScreenOn: Boolean,
    val chargingAtFull: Boolean,
    val lastBatteryPct: Int
)

/**
 * Ekran süresini kalıcı dosyada biriktirerek telefon yeniden başlatılsa dahi korur.
 * Sayaç yalnızca pil %100 (tam şarj) olduğunda sıfırlanır ve şarjdan çekilince başlar.
 */
object FullChargeTracker {

    private const val TAG = "HyperBatteryStats"
    private const val STATE_FILE_NAME = "hbs_sot_persistent_v2.txt"
    private const val LOCK_FILE_NAME = "hbs_sot_persistent_v2.lock"
    private const val EVENT_DEVICE_SHUTDOWN = 26
    private const val MIN_PERIODIC_SAVE_MS = 45_000L

    private val registered = AtomicBoolean(false)

    private val systemReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_BATTERY_CHANGED -> {
                    syncAndGetScreenOnTimeMs(context, intent, forceSave = false, explicitScreenState = null)
                }
                Intent.ACTION_POWER_DISCONNECTED -> {
                    syncAndGetScreenOnTimeMs(context, null, forceSave = true, explicitScreenState = null)
                }
                Intent.ACTION_SCREEN_ON -> {
                    syncAndGetScreenOnTimeMs(context, null, forceSave = true, explicitScreenState = true)
                }
                Intent.ACTION_SCREEN_OFF -> {
                    syncAndGetScreenOnTimeMs(context, null, forceSave = true, explicitScreenState = false)
                }
                Intent.ACTION_SHUTDOWN -> {
                    syncAndGetScreenOnTimeMs(context, null, forceSave = true, explicitScreenState = false)
                }
            }
        }
    }

    fun register(context: Context) {
        val appCtx = context.applicationContext ?: context
        if (!registered.compareAndSet(false, true)) return

        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_BATTERY_CHANGED)
                addAction(Intent.ACTION_POWER_DISCONNECTED)
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SHUTDOWN)
            }
            val sticky = appCtx.registerReceiver(systemReceiver, filter, Context.RECEIVER_EXPORTED)
            syncAndGetScreenOnTimeMs(appCtx, sticky, forceSave = true, explicitScreenState = null)
        } catch (t: Throwable) {
            registered.set(false)
            XposedBridge.log("$TAG v4.2: Tracker kayıt hatası -> ${t.message}")
        }
    }

    fun syncAndGetScreenOnTimeMs(
        context: Context,
        batteryIntent: Intent?,
        forceSave: Boolean = false,
        explicitScreenState: Boolean? = null
    ): Long {
        val appCtx = context.applicationContext ?: context
        val intent = batteryIntent ?: runCatching {
            appCtx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        }.getOrNull()

        return withStateLock(appCtx) {
            val nowWall = System.currentTimeMillis()
            val nowElapsed = SystemClock.elapsedRealtime()
            val bootWallMs = (nowWall - nowElapsed).coerceAtLeast(0L)
            val curBootCount = readBootCount(appCtx)
            val curScreenOn = explicitScreenState ?: isDeviceInteractive(appCtx)

            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = (intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100).coerceAtLeast(1)
            val pct = if (level >= 0) ((level * 100) / scale).coerceIn(0, 100) else -1
            val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0

            val isPlugged = plugged != 0
            val isFull = (pct >= 100) || (status == BatteryManager.BATTERY_STATUS_FULL)

            val prev = loadState(appCtx)

            // 1) İlk kurulum: mevcut oturumun ekran süresini başlangıç olarak al
            if (prev == null) {
                val initialSot = if (isFull && isPlugged) {
                    0L
                } else {
                    val sysStart = readSystemLastFullChargeTimestamp(appCtx)
                    if (sysStart != null && sysStart > 0L && sysStart <= nowWall) {
                        computeSotWithUnknownInitial(appCtx, sysStart, nowWall) ?: 0L
                    } else {
                        computeSotWithUnknownInitial(appCtx, bootWallMs, nowWall) ?: 0L
                    }
                }
                val initState = SotPersistentState(
                    archivedSotMs = initialSot,
                    checkpointBootCount = curBootCount,
                    checkpointWallMs = nowWall,
                    checkpointUptimeMs = nowElapsed,
                    checkpointScreenOn = curScreenOn,
                    chargingAtFull = isFull && isPlugged,
                    lastBatteryPct = if (pct >= 0) pct else 0
                )
                saveState(appCtx, initState)
                return@withStateLock initialSot
            }

            // 2) Pil %100 ve şarjda: sayaç 0 dk olarak sıfırlanır
            if (isFull && isPlugged) {
                val needWrite = !prev.chargingAtFull ||
                    prev.archivedSotMs != 0L ||
                    forceSave ||
                    (nowWall - prev.checkpointWallMs) >= MIN_PERIODIC_SAVE_MS
                if (needWrite) {
                    saveState(
                        appCtx,
                        SotPersistentState(
                            archivedSotMs = 0L,
                            checkpointBootCount = curBootCount,
                            checkpointWallMs = nowWall,
                            checkpointUptimeMs = nowElapsed,
                            checkpointScreenOn = curScreenOn,
                            chargingAtFull = true,
                            lastBatteryPct = 100
                        )
                    )
                }
                return@withStateLock 0L
            }

            // 3) %100 olduktan sonra şarjdan çekildi: ölçüm tam bu anda 0'dan başlar
            if (!isPlugged && prev.chargingAtFull) {
                saveState(
                    appCtx,
                    SotPersistentState(
                        archivedSotMs = 0L,
                        checkpointBootCount = curBootCount,
                        checkpointWallMs = nowWall,
                        checkpointUptimeMs = nowElapsed,
                        checkpointScreenOn = curScreenOn,
                        chargingAtFull = false,
                        lastBatteryPct = if (pct >= 0) pct else 100
                    )
                )
                return@withStateLock 0L
            }

            // 4) Telefon kapalıyken veya ara süreçte %100 şarj edilip çekildiyse sıfırla
            if (isFull && !isPlugged && prev.lastBatteryPct in 1..98) {
                saveState(
                    appCtx,
                    SotPersistentState(
                        archivedSotMs = 0L,
                        checkpointBootCount = curBootCount,
                        checkpointWallMs = nowWall,
                        checkpointUptimeMs = nowElapsed,
                        checkpointScreenOn = curScreenOn,
                        chargingAtFull = false,
                        lastBatteryPct = 100
                    )
                )
                return@withStateLock 0L
            }

            // 5) Yeniden başlatma (reboot) kontrolü: birikmiş ekran süresini KORU
            val rebooted = (curBootCount > 0 && prev.checkpointBootCount > 0 && curBootCount != prev.checkpointBootCount) ||
                (nowElapsed + 5_000L < prev.checkpointUptimeMs)

            if (rebooted) {
                val sinceBootMs = (computeSotWithUnknownInitial(appCtx, bootWallMs, nowWall) ?: 0L)
                    .coerceIn(0L, nowElapsed)
                val preservedTotal = prev.archivedSotMs + sinceBootMs
                saveState(
                    appCtx,
                    SotPersistentState(
                        archivedSotMs = preservedTotal,
                        checkpointBootCount = curBootCount,
                        checkpointWallMs = nowWall,
                        checkpointUptimeMs = nowElapsed,
                        checkpointScreenOn = curScreenOn,
                        chargingAtFull = false,
                        lastBatteryPct = if (pct >= 0) pct else prev.lastBatteryPct
                    )
                )
                XposedBridge.log("$TAG v4.2: Yeniden başlatma sonrası SoT korundu -> ${preservedTotal / 60_000L} dk")
                return@withStateLock preservedTotal
            }

            // 6) Aynı oturum içinde kaldığı yerden devam et
            val wallDelta = (nowWall - prev.checkpointWallMs).coerceAtLeast(0L)
            val elapsedDelta = (nowElapsed - prev.checkpointUptimeMs).coerceAtLeast(0L)
            val maxPossibleDelta = if (elapsedDelta > 0L) elapsedDelta else wallDelta

            val addedSotMs = if (wallDelta > 0L) {
                computeSotWithKnownInitial(
                    context = appCtx,
                    startMs = prev.checkpointWallMs,
                    nowMs = nowWall,
                    initialScreenOn = prev.checkpointScreenOn
                ).coerceIn(0L, maxPossibleDelta)
            } else {
                0L
            }

            val currentTotal = prev.archivedSotMs + addedSotMs

            val shouldPersist = forceSave ||
                explicitScreenState != null ||
                prev.checkpointScreenOn != curScreenOn ||
                wallDelta >= MIN_PERIODIC_SAVE_MS

            if (shouldPersist) {
                saveState(
                    appCtx,
                    SotPersistentState(
                        archivedSotMs = currentTotal,
                        checkpointBootCount = curBootCount,
                        checkpointWallMs = nowWall,
                        checkpointUptimeMs = nowElapsed,
                        checkpointScreenOn = curScreenOn,
                        chargingAtFull = false,
                        lastBatteryPct = if (pct >= 0) pct else prev.lastBatteryPct
                    )
                )
            }

            currentTotal
        }
    }

    private fun computeSotWithKnownInitial(
        context: Context,
        startMs: Long,
        nowMs: Long,
        initialScreenOn: Boolean
    ): Long {
        if (nowMs <= startMs) return 0L
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            if (usm == null) {
                return if (initialScreenOn) (nowMs - startMs) else 0L
            }

            val events = usm.queryEvents(startMs, nowMs)
            if (events == null) {
                return if (initialScreenOn) (nowMs - startMs) else 0L
            }

            val event = UsageEvents.Event()
            var isScreenOn = initialScreenOn
            var segmentStart = startMs
            var totalMs = 0L

            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                val ts = event.timeStamp
                if (ts <= startMs || ts > nowMs) continue

                when (event.eventType) {
                    UsageEvents.Event.SCREEN_INTERACTIVE -> {
                        if (!isScreenOn) {
                            isScreenOn = true
                            segmentStart = ts
                        }
                    }
                    UsageEvents.Event.SCREEN_NON_INTERACTIVE, EVENT_DEVICE_SHUTDOWN -> {
                        if (isScreenOn) {
                            totalMs += (ts - segmentStart).coerceAtLeast(0L)
                            isScreenOn = false
                        }
                    }
                }
            }

            if (isScreenOn) {
                totalMs += (nowMs - segmentStart).coerceAtLeast(0L)
            }

            totalMs.coerceAtLeast(0L)
        } catch (_: Throwable) {
            if (initialScreenOn) (nowMs - startMs) else 0L
        }
    }

    private fun computeSotWithUnknownInitial(
        context: Context,
        startMs: Long,
        nowMs: Long
    ): Long? {
        if (startMs <= 0L || nowMs <= startMs) return 0L
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                ?: return null

            val lookbackStart = (startMs - 12L * 60L * 60L * 1000L).coerceAtLeast(0L)
            val events = usm.queryEvents(lookbackStart, nowMs) ?: return null
            val event = UsageEvents.Event()

            var isScreenOn = false
            var sawEventBeforeStart = false
            var sawEventAfterStart = false
            var segmentStart = startMs
            var totalMs = 0L

            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                val ts = event.timeStamp
                val type = event.eventType

                if (type != UsageEvents.Event.SCREEN_INTERACTIVE &&
                    type != UsageEvents.Event.SCREEN_NON_INTERACTIVE &&
                    type != EVENT_DEVICE_SHUTDOWN
                ) {
                    continue
                }

                if (ts <= startMs) {
                    sawEventBeforeStart = true
                    isScreenOn = (type == UsageEvents.Event.SCREEN_INTERACTIVE)
                    segmentStart = startMs
                } else {
                    if (!sawEventAfterStart) {
                        sawEventAfterStart = true
                        if (!sawEventBeforeStart &&
                            (type == UsageEvents.Event.SCREEN_NON_INTERACTIVE || type == EVENT_DEVICE_SHUTDOWN)
                        ) {
                            isScreenOn = true
                            segmentStart = startMs
                        }
                    }

                    when (type) {
                        UsageEvents.Event.SCREEN_INTERACTIVE -> {
                            if (!isScreenOn) {
                                isScreenOn = true
                                segmentStart = ts
                            }
                        }
                        UsageEvents.Event.SCREEN_NON_INTERACTIVE, EVENT_DEVICE_SHUTDOWN -> {
                            if (isScreenOn) {
                                totalMs += (ts - segmentStart).coerceAtLeast(0L)
                                isScreenOn = false
                            }
                        }
                    }
                }
            }

            if (!sawEventAfterStart && !sawEventBeforeStart) {
                if (isDeviceInteractive(context)) {
                    totalMs += (nowMs - startMs).coerceAtLeast(0L)
                }
            } else if (isScreenOn) {
                totalMs += (nowMs - segmentStart).coerceAtLeast(0L)
            }

            totalMs.coerceAtLeast(0L)
        } catch (_: Throwable) {
            null
        }
    }

    @SuppressLint("PrivateApi")
    private fun readSystemLastFullChargeTimestamp(context: Context): Long? {
        runCatching {
            val mgr = context.getSystemService("batterystats") ?: return@runCatching null
            val stats = mgr.javaClass.getMethod("getBatteryUsageStats").invoke(mgr) ?: return@runCatching null
            extractStatsStartTimestamp(stats)
        }.getOrNull()?.let { return it }

        return runCatching {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java).invoke(null, "batterystats") as? IBinder
                ?: return@runCatching null
            val stub = Class.forName("com.android.internal.app.IBatteryStats\$Stub")
            val svc = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
                ?: return@runCatching null

            val qBuilderClass = Class.forName("android.os.BatteryUsageStatsQuery\$Builder")
            val qBuilder = qBuilderClass.getDeclaredConstructor().newInstance()
            val query = qBuilderClass.getMethod("build").invoke(qBuilder)
            val m = svc.javaClass.methods.firstOrNull {
                it.name == "getBatteryUsageStats" && it.parameterCount == 1
            } ?: return@runCatching null

            val list = m.invoke(svc, listOf(query)) as? List<*> ?: return@runCatching null
            val stats = list.firstOrNull() ?: return@runCatching null
            extractStatsStartTimestamp(stats)
        }.getOrNull()
    }

    private fun extractStatsStartTimestamp(usageStats: Any): Long? {
        val ts = runCatching {
            usageStats.javaClass.getMethod("getStatsStartTimestamp").invoke(usageStats) as? Long
        }.getOrNull() ?: return null
        val now = System.currentTimeMillis()
        val maxAgeMs = 14L * 24L * 60L * 60L * 1000L
        return ts.takeIf { it > 0L && it <= now && (now - it) <= maxAgeMs }
    }

    private fun readBootCount(context: Context): Int {
        return runCatching {
            Settings.Global.getInt(context.contentResolver, Settings.Global.BOOT_COUNT, 0)
        }.getOrDefault(0)
    }

    private fun isDeviceInteractive(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        return pm?.isInteractive ?: false
    }

    private fun <T> withStateLock(context: Context, block: () -> T): T {
        val lockFile = File(context.filesDir, LOCK_FILE_NAME)
        return try {
            RandomAccessFile(lockFile, "rw").use { raf ->
                raf.channel.lock().use {
                    block()
                }
            }
        } catch (_: Throwable) {
            synchronized(this) {
                block()
            }
        }
    }

    private fun stateFile(context: Context): File = File(context.filesDir, STATE_FILE_NAME)

    private fun loadState(context: Context): SotPersistentState? {
        return try {
            val file = stateFile(context)
            if (!file.exists()) return null
            val parts = file.readText().trim().split(",")
            if (parts.size < 7) return null
            SotPersistentState(
                archivedSotMs = parts[0].toLongOrNull() ?: return null,
                checkpointBootCount = parts[1].toIntOrNull() ?: 0,
                checkpointWallMs = parts[2].toLongOrNull() ?: return null,
                checkpointUptimeMs = parts[3].toLongOrNull() ?: 0L,
                checkpointScreenOn = parts[4] == "1",
                chargingAtFull = parts[5] == "1",
                lastBatteryPct = parts[6].toIntOrNull() ?: 0
            )
        } catch (_: Throwable) {
            null
        }
    }

    private fun saveState(context: Context, s: SotPersistentState) {
        try {
            val line = listOf(
                s.archivedSotMs,
                s.checkpointBootCount,
                s.checkpointWallMs,
                s.checkpointUptimeMs,
                if (s.checkpointScreenOn) 1 else 0,
                if (s.chargingAtFull) 1 else 0,
                s.lastBatteryPct
            ).joinToString(",")

            val target = stateFile(context)
            val tmp = File(target.parentFile, "$STATE_FILE_NAME.tmp")
            tmp.writeText(line)
            if (!tmp.renameTo(target)) {
                target.writeText(line)
                tmp.delete()
            }
        } catch (_: Throwable) {
            // Dosya yazılamazsa sessizce geç
        }
    }
}
