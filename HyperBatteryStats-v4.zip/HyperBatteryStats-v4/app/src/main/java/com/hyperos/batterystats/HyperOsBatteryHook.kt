package com.hyperos.batterystats

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.util.WeakHashMap

class HyperOsBatteryHook : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "HyperBatteryStats"
        private const val INLINE_SECTION_TAG = "hyperos4_inline_battery_section"
        private const val CAT_KEY = "hbs_cat_stats"
        private const val KEY_SOT = "hbs_row_sot"
        private const val KEY_TEMP = "hbs_row_temp"
        private const val KEY_CYCLE = "hbs_row_cycle"
        private const val KEY_CAP = "hbs_row_cap"

        private val TARGET_PACKAGES = setOf(
            "com.miui.securitycenter",
            "com.android.settings"
        )
    }

    private val mainHandler by lazy { Handler(Looper.getMainLooper()) }
    private val refreshTasks = WeakHashMap<Activity, Runnable>()

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName !in TARGET_PACKAGES) return

        XposedBridge.log("$TAG v4: ${lpparam.packageName} bağlandı.")

        // Güvenlik uygulaması arka planda sürekli çalıştığı için %100 şarj anını anında yakala
        if (lpparam.packageName == "com.miui.securitycenter") {
            XposedHelpers.findAndHookMethod(
                Application::class.java,
                "onCreate",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val app = param.thisObject as? Application ?: return
                        FullChargeTracker.register(app.applicationContext)
                    }
                }
            )
        }

        XposedHelpers.findAndHookMethod(
            Activity::class.java,
            "onResume",
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val activity = param.thisObject as? Activity ?: return
                    if (!isBatteryActivity(activity)) return
                    FullChargeTracker.register(activity.applicationContext)
                    scheduleInjection(activity)
                }
            }
        )

        XposedHelpers.findAndHookMethod(
            Activity::class.java,
            "onPause",
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val activity = param.thisObject as? Activity ?: return
                    refreshTasks.remove(activity)?.let { mainHandler.removeCallbacks(it) }
                }
            }
        )
    }

    private fun isBatteryActivity(activity: Activity): Boolean {
        val name = activity.javaClass.name.lowercase()
        if (name.contains("dialog") || name.contains("popup") || name.contains("transparent")) {
            return false
        }
        val action = activity.intent?.action?.lowercase() ?: ""
        val title = activity.title?.toString()?.lowercase() ?: ""
        return name.contains("powercenter") ||
            name.contains("battery") ||
            name.contains("powermain") ||
            name.contains("powersettings") ||
            name.contains("powerusage") ||
            name.contains("chargefeature") ||
            action.contains("power_usage") ||
            action.contains("battery") ||
            title == "pil" ||
            title == "battery"
    }

    private fun scheduleInjection(activity: Activity) {
        refreshTasks.remove(activity)?.let { mainHandler.removeCallbacks(it) }

        val task = object : Runnable {
            override fun run() {
                if (activity.isFinishing || activity.isDestroyed) return
                val injected = injectNatively(activity)
                val nextDelay = if (injected) 4000L else 500L
                mainHandler.postDelayed(this, nextDelay)
            }
        }
        refreshTasks[activity] = task
        mainHandler.postDelayed(task, 180L)
    }

    private fun injectNatively(activity: Activity): Boolean {
        val snapshot = BatteryMetricsReader.read(activity)

        // 1. Öncelik: Doğrudan HyperOS ayar listesine (PreferenceScreen / Pil bilgileri) satır ekle
        val prefScreen = findPreferenceScreen(activity)
        if (prefScreen != null) {
            if (injectIntoPreferenceScreen(activity, prefScreen, snapshot)) {
                return true
            }
        }

        // 2. Öncelik: Kaydırılabilir sayfa içi ayar bölümü
        val root = activity.findViewById<ViewGroup>(android.R.id.content) ?: return false
        return injectIntoScrollableLayout(activity, root, snapshot)
    }

    private fun sotLabelFor(source: SotSource): String = when (source) {
        SotSource.FULL_CHARGE_TRACKED -> "Ekran süresi"
        SotSource.SYSTEM_LAST_CHARGE -> "Ekran süresi"
        SotSource.WAITING_FULL_CHARGE -> "Ekran süresi (tam şarj bekleniyor)"
    }

    // ==================== 1. YÖNTEM: DOĞAL PREFERENCE ENJEKSİYONU ====================

    private fun findPreferenceScreen(activity: Activity): Any? {
        findPrefScreenFromFragmentManager(activity, "getSupportFragmentManager")?.let { return it }
        findPrefScreenFromFragmentManager(activity, "getFragmentManager")?.let { return it }

        val root = activity.findViewById<ViewGroup>(android.R.id.content) ?: return null
        return findPrefScreenFromRecyclerView(root)
    }

    private fun findPrefScreenFromFragmentManager(host: Any, getterName: String): Any? {
        return try {
            val fmMethod = host.javaClass.methods.firstOrNull {
                it.name == getterName && it.parameterCount == 0
            } ?: return null
            val fm = fmMethod.invoke(host) ?: return null
            val getFrags = fm.javaClass.methods.firstOrNull {
                it.name == "getFragments" && it.parameterCount == 0
            } ?: return null
            val frags = getFrags.invoke(fm) as? Collection<*> ?: return null

            for (frag in frags) {
                if (frag == null) continue
                val psMethod = frag.javaClass.methods.firstOrNull {
                    it.name == "getPreferenceScreen" && it.parameterCount == 0
                }
                if (psMethod != null) {
                    val ps = psMethod.invoke(frag)
                    if (ps != null && isPreferenceGroup(ps)) return ps
                }
                findPrefScreenFromFragmentManager(frag, "getChildFragmentManager")?.let { return it }
            }
            null
        } catch (_: Throwable) {
            null
        }
    }

    private fun findPrefScreenFromRecyclerView(view: View): Any? {
        if (view.javaClass.name.contains("RecyclerView", ignoreCase = true)) {
            val adapter = runCatching {
                view.javaClass.getMethod("getAdapter").invoke(view)
            }.getOrNull()
            if (adapter != null) {
                var cls: Class<*>? = adapter.javaClass
                while (cls != null && cls != Any::class.java) {
                    for (field in cls.declaredFields) {
                        val value = runCatching {
                            field.isAccessible = true
                            field.get(adapter)
                        }.getOrNull() ?: continue
                        if (isPreferenceGroup(value)) return value
                    }
                    cls = cls.superclass
                }
            }
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                findPrefScreenFromRecyclerView(view.getChildAt(i))?.let { return it }
            }
        }
        return null
    }

    private fun isPreferenceGroup(obj: Any): Boolean {
        val methods = obj.javaClass.methods
        val hasAdd = methods.any { it.name == "addPreference" && it.parameterCount == 1 }
        val hasCount = methods.any { it.name == "getPreferenceCount" && it.parameterCount == 0 }
        return hasAdd && hasCount
    }

    private fun injectIntoPreferenceScreen(
        activity: Activity,
        prefScreen: Any,
        snapshot: BatterySnapshot
    ): Boolean {
        return try {
            val prefContext = runCatching {
                prefScreen.javaClass.getMethod("getContext").invoke(prefScreen) as? Context
            }.getOrNull() ?: activity

            val cl = prefScreen.javaClass.classLoader ?: activity.classLoader
            val existingCategory = findBatteryInfoCategory(prefScreen)
            val hasNativeCycle = hasExistingPreferenceMatching(prefScreen, listOf("döngü", "cycle"))

            val targetGroup: Any
            val samplePref: Any?

            if (existingCategory != null) {
                targetGroup = existingCategory
                samplePref = findSampleTextPreference(existingCategory)
            } else {
                val existingCat = callFindPreference(prefScreen, CAT_KEY)
                if (existingCat != null && isPreferenceGroup(existingCat)) {
                    targetGroup = existingCat
                } else {
                    val createdCat = createPreferenceCategory(prefContext, prefScreen, cl)
                    if (createdCat != null) {
                        callSetter(createdCat, "setKey", CAT_KEY)
                        callSetter(createdCat, "setTitle", "Detaylı pil istatistikleri")
                        callSetter(createdCat, "setOrder", 100)
                        callAddPreference(prefScreen, createdCat)
                        targetGroup = createdCat
                    } else {
                        targetGroup = prefScreen
                    }
                }
                samplePref = findSampleTextPreference(prefScreen)
            }

            val rows = mutableListOf(
                Triple(
                    KEY_SOT,
                    sotLabelFor(snapshot.sotSource),
                    BatteryMetricsReader.formatDuration(snapshot.screenOnTimeMs)
                ),
                Triple(
                    KEY_TEMP,
                    "Pil sıcaklığı",
                    BatteryMetricsReader.formatTemp(snapshot.temperatureC)
                )
            )
            if (!hasNativeCycle) {
                val cycleText = snapshot.cycleCount?.toString() ?: "N/A"
                rows.add(Triple(KEY_CYCLE, "Döngüler", cycleText))
            }
            rows.add(
                Triple(
                    KEY_CAP,
                    "Gerçek kapasite",
                    BatteryMetricsReader.formatCapacity(
                        snapshot.realCapacityMah,
                        snapshot.designCapacityMah,
                        snapshot.healthPercent
                    )
                )
            )

            var orderBase = 1000
            for ((key, title, value) in rows) {
                upsertPreferenceRow(prefContext, cl, prefScreen, targetGroup, samplePref, key, title, value, orderBase++)
            }
            true
        } catch (t: Throwable) {
            XposedBridge.log("$TAG v4: PreferenceScreen enjeksiyon hatası -> ${t.message}")
            false
        }
    }

    private fun findBatteryInfoCategory(prefScreen: Any): Any? {
        val count = getPreferenceCount(prefScreen)
        for (i in 0 until count) {
            val child = getPreferenceAt(prefScreen, i) ?: continue
            if (!isPreferenceGroup(child)) continue

            val title = getPreferenceTitle(child).lowercase()
            if (title.contains("pil bilgi") || title.contains("battery info") || title.contains("pil durum")) {
                return child
            }
            val innerCount = getPreferenceCount(child)
            for (j in 0 until innerCount) {
                val inner = getPreferenceAt(child, j) ?: continue
                val innerTitle = getPreferenceTitle(inner).lowercase()
                if (innerTitle.contains("pil sağlığı") ||
                    innerTitle.contains("battery health") ||
                    innerTitle.contains("döngü") ||
                    innerTitle.contains("üretim tarihi") ||
                    innerTitle.contains("manufacture")
                ) {
                    return child
                }
            }
        }
        return null
    }

    private fun hasExistingPreferenceMatching(group: Any, keywords: List<String>): Boolean {
        val count = getPreferenceCount(group)
        for (i in 0 until count) {
            val child = getPreferenceAt(group, i) ?: continue
            val key = runCatching { child.javaClass.getMethod("getKey").invoke(child) as? String }.getOrNull() ?: ""
            if (key.startsWith("hbs_")) continue

            val title = getPreferenceTitle(child).lowercase()
            if (keywords.any { title.contains(it) }) return true

            if (isPreferenceGroup(child) && hasExistingPreferenceMatching(child, keywords)) {
                return true
            }
        }
        return false
    }

    private fun findSampleTextPreference(group: Any): Any? {
        val count = getPreferenceCount(group)
        for (i in 0 until count) {
            val child = getPreferenceAt(group, i) ?: continue
            if (isPreferenceGroup(child)) {
                findSampleTextPreference(child)?.let { return it }
            } else {
                val hasSetText = child.javaClass.methods.any { it.name == "setText" && it.parameterCount == 1 }
                if (hasSetText) return child
            }
        }
        return null
    }

    private fun createPreferenceCategory(context: Context, prefScreen: Any, cl: ClassLoader): Any? {
        val count = getPreferenceCount(prefScreen)
        for (i in 0 until count) {
            val child = getPreferenceAt(prefScreen, i) ?: continue
            if (isPreferenceGroup(child) && child.javaClass.name.contains("Category", ignoreCase = true)) {
                instantiatePreferenceClass(child.javaClass, context)?.let { return it }
            }
        }
        val candidates = listOf(
            "miuix.preference.PreferenceCategory",
            "androidx.preference.PreferenceCategory"
        )
        for (name in candidates) {
            val cls = XposedHelpers.findClassIfExists(name, cl) ?: continue
            instantiatePreferenceClass(cls, context)?.let { return it }
        }
        return null
    }

    private fun upsertPreferenceRow(
        context: Context,
        cl: ClassLoader,
        prefScreen: Any,
        targetGroup: Any,
        samplePref: Any?,
        key: String,
        title: String,
        value: String,
        order: Int
    ) {
        val existing = callFindPreference(prefScreen, key)
        if (existing != null) {
            applyTitleAndValue(existing, title, value)
            return
        }

        val pref = createValuePreference(context, cl, samplePref) ?: return
        callSetter(pref, "setKey", key)
        callSetter(pref, "setOrder", order)
        callBoolSetter(pref, "setSelectable", false)
        callBoolSetter(pref, "setIconSpaceReserved", false)
        applyTitleAndValue(pref, title, value)
        callAddPreference(targetGroup, pref)
    }

    private fun createValuePreference(context: Context, cl: ClassLoader, samplePref: Any?): Any? {
        if (samplePref != null) {
            instantiatePreferenceClass(samplePref.javaClass, context)?.let { return it }
        }
        val candidates = listOf(
            "miuix.preference.TextPreference",
            "androidx.preference.Preference"
        )
        for (name in candidates) {
            val cls = XposedHelpers.findClassIfExists(name, cl) ?: continue
            instantiatePreferenceClass(cls, context)?.let { return it }
        }
        return null
    }

    private fun instantiatePreferenceClass(cls: Class<*>, context: Context): Any? {
        return try {
            cls.getConstructor(Context::class.java).newInstance(context)
        } catch (_: Throwable) {
            try {
                cls.getConstructor(Context::class.java, AttributeSet::class.java)
                    .newInstance(context, null)
            } catch (_: Throwable) {
                null
            }
        }
    }

    private fun applyTitleAndValue(pref: Any, title: String, value: String) {
        callSetter(pref, "setTitle", title)
        val setTextMethod = pref.javaClass.methods.firstOrNull {
            it.name == "setText" && it.parameterCount == 1 &&
                (it.parameterTypes[0] == String::class.java ||
                    it.parameterTypes[0] == CharSequence::class.java)
        }
        if (setTextMethod != null) {
            runCatching { setTextMethod.invoke(pref, value) }
        } else {
            callSetter(pref, "setSummary", value)
        }
    }

    private fun getPreferenceCount(group: Any): Int =
        runCatching { group.javaClass.getMethod("getPreferenceCount").invoke(group) as Int }
            .getOrDefault(0)

    private fun getPreferenceAt(group: Any, index: Int): Any? =
        runCatching {
            group.javaClass.getMethod("getPreference", Int::class.javaPrimitiveType)
                .invoke(group, index)
        }.getOrNull()

    private fun getPreferenceTitle(pref: Any): String =
        runCatching { pref.javaClass.getMethod("getTitle").invoke(pref)?.toString() }
            .getOrNull() ?: ""

    private fun callFindPreference(group: Any, key: String): Any? {
        return runCatching {
            val m = group.javaClass.methods.firstOrNull {
                it.name == "findPreference" && it.parameterCount == 1
            } ?: return null
            m.invoke(group, key)
        }.getOrNull()
    }

    private fun callAddPreference(group: Any, pref: Any) {
        val m = group.javaClass.methods.firstOrNull {
            it.name == "addPreference" && it.parameterCount == 1
        } ?: return
        m.invoke(group, pref)
    }

    private fun callSetter(target: Any, methodName: String, value: Any) {
        val m = target.javaClass.methods.firstOrNull {
            it.name == methodName && it.parameterCount == 1 &&
                (it.parameterTypes[0].isAssignableFrom(value.javaClass) ||
                    (value is Int && it.parameterTypes[0] == Int::class.javaPrimitiveType))
        } ?: return
        runCatching { m.invoke(target, value) }
    }

    private fun callBoolSetter(target: Any, methodName: String, value: Boolean) {
        val m = target.javaClass.methods.firstOrNull {
            it.name == methodName && it.parameterCount == 1 &&
                it.parameterTypes[0] == Boolean::class.javaPrimitiveType
        } ?: return
        runCatching { m.invoke(target, value) }
    }

    // ==================== 2. YÖNTEM: KAYDIRILABİLİR SAYFA İÇİ GÖMÜLÜ KART ====================

    private fun injectIntoScrollableLayout(
        activity: Activity,
        root: ViewGroup,
        snapshot: BatterySnapshot
    ): Boolean {
        val existing = root.findViewWithTag<LinearLayout>(INLINE_SECTION_TAG)
        if (existing != null) {
            updateInlineSection(existing, snapshot)
            return true
        }

        val targetContainer = findScrollableLinearContainer(root) ?: return false
        val section = buildNativeInlineSection(activity)
        updateInlineSection(section, snapshot)

        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(activity, 8)
            bottomMargin = dp(activity, 20)
        }
        targetContainer.addView(section, lp)
        return true
    }

    private fun findScrollableLinearContainer(view: View): LinearLayout? {
        val clsName = view.javaClass.name
        val isScroll = view is ScrollView || clsName.contains("ScrollView", ignoreCase = true)
        if (isScroll && view is ViewGroup && view.childCount > 0) {
            val firstChild = view.getChildAt(0)
            if (firstChild is LinearLayout && firstChild.orientation == LinearLayout.VERTICAL) {
                return firstChild
            }
            if (firstChild is ViewGroup) {
                findVerticalLinearChild(firstChild)?.let { return it }
            }
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                findScrollableLinearContainer(view.getChildAt(i))?.let { return it }
            }
        }
        return null
    }

    private fun findVerticalLinearChild(group: ViewGroup): LinearLayout? {
        for (i in 0 until group.childCount) {
            val child = group.getChildAt(i)
            if (child is LinearLayout && child.orientation == LinearLayout.VERTICAL && child.childCount >= 2) {
                return child
            }
        }
        return null
    }

    private fun buildNativeInlineSection(activity: Activity): LinearLayout {
        val isDark = (activity.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES

        val sectionHeaderColor = if (isDark) Color.parseColor("#8E8E93") else Color.parseColor("#6E6E73")
        val cardBgColor = if (isDark) Color.parseColor("#1F1F21") else Color.parseColor("#FFFFFF")
        val labelColor = if (isDark) Color.parseColor("#FFFFFF") else Color.parseColor("#111111")
        val valueColor = if (isDark) Color.parseColor("#8E8E93") else Color.parseColor("#6E6E73")

        val wrapper = LinearLayout(activity).apply {
            tag = INLINE_SECTION_TAG
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 16), dp(activity, 8), dp(activity, 16), dp(activity, 8))
        }

        val headerTv = TextView(activity).apply {
            text = "Detaylı pil istatistikleri"
            setTextColor(sectionHeaderColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(dp(activity, 16), dp(activity, 4), dp(activity, 16), dp(activity, 8))
        }

        val card = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 18), dp(activity, 6), dp(activity, 18), dp(activity, 6))
            background = GradientDrawable().apply {
                cornerRadius = dp(activity, 20).toFloat()
                setColor(cardBgColor)
            }
        }

        val rows = listOf(
            Pair("sot", "Ekran süresi"),
            Pair("temp", "Pil sıcaklığı"),
            Pair("cycle", "Döngüler"),
            Pair("cap", "Gerçek kapasite")
        )

        for ((tagKey, label) in rows) {
            val row = LinearLayout(activity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(activity, 13), 0, dp(activity, 13))
            }

            val leftTv = TextView(activity).apply {
                tag = "label_$tagKey"
                text = label
                setTextColor(labelColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15.5f)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val rightTv = TextView(activity).apply {
                tag = "val_$tagKey"
                text = "--"
                setTextColor(valueColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                gravity = Gravity.END
            }

            row.addView(leftTv)
            row.addView(rightTv)
            card.addView(row)
        }

        wrapper.addView(headerTv)
        wrapper.addView(card)
        return wrapper
    }

    private fun updateInlineSection(section: LinearLayout, s: BatterySnapshot) {
        section.findViewWithTag<TextView>("label_sot")?.text = sotLabelFor(s.sotSource)
        section.findViewWithTag<TextView>("val_sot")?.text = BatteryMetricsReader.formatDuration(s.screenOnTimeMs)
        section.findViewWithTag<TextView>("val_temp")?.text = BatteryMetricsReader.formatTemp(s.temperatureC)
        section.findViewWithTag<TextView>("val_cycle")?.text = s.cycleCount?.toString() ?: "N/A"
        section.findViewWithTag<TextView>("val_cap")?.text = BatteryMetricsReader.formatCapacity(
            s.realCapacityMah,
            s.designCapacityMah,
            s.healthPercent
        )
    }

    private fun dp(activity: Activity, value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            activity.resources.displayMetrics
        ).toInt()
    }
}
