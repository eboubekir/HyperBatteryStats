package com.hyperos.batterystats

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import de.robv.android.xposed.XposedBridge
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

data class FullChargeState(
    val resetTimestampMs: Long,
    val chargingAtFull: Boolean
)

/**
 * Pil %100 (tam şarj) olduğunda ve şarjdan çekildiğinde başlangıç zamanını
 * kalıcı olarak kaydeder. Sadece %100'e ulaşıldığında sıfırlanır.
 */
object FullChargeTracker {

    private const val STATE_FILE_NAME = "hbs_full_charge_state.txt"
    private const val RECHARGE_GAP_MS = 20L * 60L * 1000L
    private const val FULL_PLUGGED_REFRESH_MS = 15_000L

    private val registered = AtomicBoolean(false)

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_BATTERY_CHANGED -> processBatteryIntent(context, intent)
                Intent.ACTION_POWER_DISCONNECTED -> onPowerDisconnected(context)
            }
        }
    }

    fun register(context: Context) {
        val appCtx = context.applicationContext ?: context
        if (!registered.compareAndSet(false, true)) return

        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_BATTERY_CHANGED)
                addAction(Intent.ACTION_POWER_DISCONNECTED)
            }
            val sticky = appCtx.registerReceiver(batteryReceiver, filter, Context.RECEIVER_EXPORTED)
            if (sticky != null) {
                processBatteryIntent(appCtx, sticky)
            }
        } catch (t: Throwable) {
            registered.set(false)
            XposedBridge.log("HyperBatteryStats v4: FullChargeTracker kayıt hatası -> ${t.message}")
        }
    }

    fun processBatteryIntent(context: Context, intent: Intent?) {
        if (intent == null) return
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val pct = if (level >= 0) (level * 100) / scale else -1
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)

        val isPlugged = plugged != 0
        val isFull = (pct >= 100) || (status == BatteryManager.BATTERY_STATUS_FULL)
        val now = System.currentTimeMillis()
        val state = loadState(context)

        when {
            isFull && isPlugged -> {
                // %100 dolu ve hâlâ şarjda: ölçüm sıfırda tutulur
                if (!state.chargingAtFull || (now - state.resetTimestampMs) >= FULL_PLUGGED_REFRESH_MS) {
                    saveState(context, FullChargeState(resetTimestampMs = now, chargingAtFull = true))
                }
            }
            !isPlugged && state.chargingAtFull -> {
                // %100 olduktan sonra şarjdan çekildi: ölçüm tam bu anda başlar
                saveState(context, FullChargeState(resetTimestampMs = now, chargingAtFull = false))
            }
            isFull && !isPlugged -> {
                // Kapalıyken %100 şarj edilip açıldıysa veya ilk kez %100'de görülüyorsa
                if (state.resetTimestampMs <= 0L || (now - state.resetTimestampMs) > RECHARGE_GAP_MS) {
                    saveState(context, FullChargeState(resetTimestampMs = now, chargingAtFull = false))
                }
            }
            !isFull && !isPlugged && state.chargingAtFull -> {
                saveState(context, FullChargeState(resetTimestampMs = now, chargingAtFull = false))
            }
        }
    }

    private fun onPowerDisconnected(context: Context) {
        val state = loadState(context)
        if (state.chargingAtFull) {
            saveState(context, FullChargeState(resetTimestampMs = System.currentTimeMillis(), chargingAtFull = false))
        }
    }

    fun isCurrentlyFullAndPlugged(intent: Intent?): Boolean {
        if (intent == null) return false
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val pct = if (level >= 0) (level * 100) / scale else -1
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        return plugged != 0 && ((pct >= 100) || (status == BatteryManager.BATTERY_STATUS_FULL))
    }

    fun getLastFullChargeTimestamp(context: Context): Long {
        return loadState(context).resetTimestampMs
    }

    private fun stateFile(context: Context): File {
        val dir = (context.applicationContext ?: context).filesDir
        return File(dir, STATE_FILE_NAME)
    }

    private fun loadState(context: Context): FullChargeState {
        return try {
            val file = stateFile(context)
            if (!file.exists()) return FullChargeState(0L, false)
            val parts = file.readText().trim().split(",")
            val ts = parts.getOrNull(0)?.toLongOrNull() ?: 0L
            val fullPlugged = parts.getOrNull(1) == "1"
            FullChargeState(ts, fullPlugged)
        } catch (_: Throwable) {
            FullChargeState(0L, false)
        }
    }

    private fun saveState(context: Context, state: FullChargeState) {
        try {
            val target = stateFile(context)
            val tmp = File(target.parentFile, "$STATE_FILE_NAME.tmp")
            tmp.writeText("${state.resetTimestampMs},${if (state.chargingAtFull) 1 else 0}")
            if (!tmp.renameTo(target)) {
                target.writeText("${state.resetTimestampMs},${if (state.chargingAtFull) 1 else 0}")
                tmp.delete()
            }
        } catch (_: Throwable) {
            // Dosya yazılamazsa sessizce geç
        }
    }
}
