package com.hyperos.batterystats

import android.app.Activity
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.util.WeakHashMap

class HyperOsBatteryHook : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "HyperBatteryStats"
        private const val CARD_TAG = "hyperos4_battery_overlay_card"
        private val TARGET_PACKAGES = setOf(
            "com.miui.securitycenter",
            "com.android.settings"
        )
    }

    private val mainHandler by lazy { Handler(Looper.getMainLooper()) }
    private val refreshTasks = WeakHashMap<Activity, Runnable>()

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName !in TARGET_PACKAGES) return

        XposedBridge.log("$TAG v2: ${lpparam.packageName} bağlandı.")

        XposedHelpers.findAndHookMethod(
            Activity::class.java,
            "onResume",
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val activity = param.thisObject as? Activity ?: return
                    if (!isBatteryActivity(activity)) return
                    mainHandler.post { attachOrRefreshCard(activity) }
                }
            }
        )

        XposedHelpers.findAndHookMethod(
            Activity::class.java,
            "onPause",
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val activity = param.thisObject as? Activity ?: return
                    refreshTasks.remove(activity)?.let { mainHandler.removeCallbacks(it) }
                }
            }
        )
    }

    private fun isBatteryActivity(activity: Activity): Boolean {
        val name = activity.javaClass.name.lowercase()
        if (name.contains("dialog") || name.contains("popup") || name.contains("transparent")) {
            return false
        }
        val action = activity.intent?.action?.lowercase() ?: ""
        val title = activity.title?.toString()?.lowercase() ?: ""
        return name.contains("powercenter") ||
            name.contains("battery") ||
            name.contains("powermain") ||
            name.contains("powersettings") ||
            name.contains("powerusage") ||
            name.contains("chargefeature") ||
            action.contains("power_usage") ||
            action.contains("battery") ||
            title == "pil" ||
            title == "battery"
    }

    private fun attachOrRefreshCard(activity: Activity) {
        if (activity.isFinishing || activity.isDestroyed) return
        val root = activity.findViewById<ViewGroup>(android.R.id.content) ?: return

        var card = root.findViewWithTag<LinearLayout>(CARD_TAG)
        if (card == null) {
            card = buildCard(activity)
            val lp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            )
            val hMargin = dp(activity, 14)
            val bMargin = dp(activity, 52)
            lp.setMargins(hMargin, 0, hMargin, bMargin)
            root.addView(card, lp)
            card.bringToFront()
            XposedBridge.log("$TAG v2: Kart eklendi -> ${activity.javaClass.name}")
        }

        updateCardData(activity, card)

        refreshTasks.remove(activity)?.let { mainHandler.removeCallbacks(it) }
        val task = object : Runnable {
            override fun run() {
                if (!activity.isFinishing && !activity.isDestroyed && card.isAttachedToWindow) {
                    updateCardData(activity, card)
                    mainHandler.postDelayed(this, 4000L)
                }
            }
        }
        refreshTasks[activity] = task
        mainHandler.postDelayed(task, 4000L)
    }

    private fun buildCard(activity: Activity): LinearLayout {
        val isDark = (activity.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES

        val bgColor = if (isDark) Color.parseColor("#EB1C1C1E") else Color.parseColor("#F2FFFFFF")
        val strokeColor = if (isDark) Color.parseColor("#33FFFFFF") else Color.parseColor("#22000000")
        val titleColor = if (isDark) Color.parseColor("#FFFFFF") else Color.parseColor("#111111")
        val bodyColor = if (isDark) Color.parseColor("#D1D1D6") else Color.parseColor("#333333")
        val accentColor = Color.parseColor("#3482FF")

        val card = LinearLayout(activity).apply {
            tag = CARD_TAG
            orientation = LinearLayout.VERTICAL
            setPadding(dp(activity, 16), dp(activity, 12), dp(activity, 16), dp(activity, 12))
            elevation = dp(activity, 12).toFloat()
            translationZ = dp(activity, 12).toFloat()
            background = GradientDrawable().apply {
                cornerRadius = dp(activity, 20).toFloat()
                setColor(bgColor)
                setStroke(dp(activity, 1), strokeColor)
            }
        }

        val header = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleTv = TextView(activity).apply {
            text = "Pil İstatistikleri (Canlı)"
            setTextColor(titleColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val bodyTv = TextView(activity).apply {
            tag = "body_text"
            setTextColor(bodyColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setLineSpacing(dp(activity, 3).toFloat(), 1f)
            setPadding(0, dp(activity, 6), 0, 0)
        }

        val toggleBtn = TextView(activity).apply {
            text = "Gizle"
            setTextColor(accentColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(activity, 10), dp(activity, 4), dp(activity, 4), dp(activity, 4))
            setOnClickListener {
                if (bodyTv.visibility == View.VISIBLE) {
                    bodyTv.visibility = View.GONE
                    text = "Göster"
                } else {
                    bodyTv.visibility = View.VISIBLE
                    text = "Gizle"
                    updateCardData(activity, card)
                }
            }
        }

        header.addView(titleTv)
        header.addView(toggleBtn)
        card.addView(header)
        card.addView(bodyTv)

        card.setOnClickListener {
            updateCardData(activity, card)
        }

        return card
    }

    private fun updateCardData(activity: Activity, card: LinearLayout) {
        val bodyTv = card.findViewWithTag<TextView>("body_text") ?: return
        val s = BatteryMetricsReader.read(activity)
        val sotLabel = if (s.sotIs24hFallback) "Ekran Süresi (24 sa)" else "Ekran Süresi (SoT)"
        val sotVal = BatteryMetricsReader.formatDuration(s.screenOnTimeMs)
        val tempVal = BatteryMetricsReader.formatTemp(s.temperatureC)
        val wattVal = BatteryMetricsReader.formatPower(s.powerWatts, s.isCharging)
        val cycleVal = s.cycleCount?.let { "$it döngü" } ?: "N/A"
        val capVal = BatteryMetricsReader.formatCapacity(
            s.realCapacityMah,
            s.designCapacityMah,
            s.healthPercent
        )

        bodyTv.text = buildString {
            append("$sotLabel: $sotVal\n")
            append("Sıcaklık: $tempVal  |  Güç: $wattVal\n")
            append("Döngü: $cycleVal\n")
            append("Gerçek Kapasite: $capVal")
        }
    }

    private fun dp(activity: Activity, value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            activity.resources.displayMetrics
        ).toInt()
    }
}
