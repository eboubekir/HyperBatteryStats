package com.hyperos.batterystats

import android.annotation.SuppressLint
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

enum class SotSource {
    FULL_CHARGE_TRACKED,
    SYSTEM_LAST_CHARGE,
    WAITING_FULL_CHARGE
}

data class BatterySnapshot(
    val temperatureC: Float?,
    val cycleCount: Int?,
    val realCapacityMah: Int?,
    val designCapacityMah: Int?,
    val healthPercent: Int?,
    val screenOnTimeMs: Long?,
    val sotSource: SotSource
)

object BatteryMetricsReader {

    private const val EVENT_DEVICE_SHUTDOWN = 26

    fun read(context: Context): BatterySnapshot {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        FullChargeTracker.processBatteryIntent(context, intent)

        val tempC = readTemperature(intent)
        val cycles = readCycleCount(intent)
        val (realMah, designMah) = readCapacities(context)

        val healthPct = if (realMah != null && designMah != null && designMah > 0) {
            ((realMah.toDouble() / designMah.toDouble()) * 100.0)
                .roundToInt()
                .coerceIn(1, 100)
        } else null

        val (sotMs, sotSource) = readScreenOnTimeSinceFullCharge(context, intent)

        return BatterySnapshot(
            temperatureC = tempC,
            cycleCount = cycles,
            realCapacityMah = realMah,
            designCapacityMah = designMah,
            healthPercent = healthPct,
            screenOnTimeMs = sotMs,
            sotSource = sotSource
        )
    }

    private fun powerSupplyDirs(): List<File> {
        val preferred = listOf("bms", "battery", "maxfg", "qcom-battery", "mtk-gauge", "xm_bms")
        val root = File("/sys/class/power_supply")
        val all = root.listFiles()?.filter { it.isDirectory } ?: emptyList()
        val ordered = mutableListOf<File>()
        for (name in preferred) {
            all.firstOrNull { it.name.equals(name, ignoreCase = true) }?.let { ordered.add(it) }
        }
        for (dir in all) {
            if (ordered.none { it.absolutePath == dir.absolutePath }) ordered.add(dir)
        }
        val qcomDir = File("/sys/class/qcom-battery")
        if (qcomDir.isDirectory) ordered.add(qcomDir)
        return ordered
    }

    private fun readSysfsLong(fileName: String): Long? {
        for (dir in powerSupplyDirs()) {
            val v = readLongFile(File(dir, fileName))
            if (v != null) return v
        }
        return null
    }

    private fun readLongFile(file: File): Long? {
        return try {
            if (file.exists() && file.canRead()) {
                file.readText().trim().toLongOrNull()
            } else null
        } catch (_: Throwable) {
            null
        }
    }

    private fun normalizeMah(raw: Long?): Int? {
        if (raw == null || raw <= 0L) return null
        return if (raw > 100_000L) (raw / 1000L).toInt() else raw.toInt()
    }

    private fun readTemperature(intent: Intent?): Float? {
        val t = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        if (t != null && t != Int.MIN_VALUE && t > 0) return t / 10f
        val sys = readSysfsLong("temp") ?: return null
        return sys / 10f
    }

    private fun readCycleCount(intent: Intent?): Int? {
        val extra = intent?.getIntExtra("android.os.extra.CYCLE_COUNT", -1) ?: -1
        if (extra >= 0) return extra
        return readSysfsLong("cycle_count")?.takeIf { it >= 0L }?.toInt()
    }

    private fun readCapacities(context: Context): Pair<Int?, Int?> {
        for (dir in powerSupplyDirs()) {
            val full = normalizeMah(readLongFile(File(dir, "charge_full")))
            val design = normalizeMah(readLongFile(File(dir, "charge_full_design")))
            if (full != null && design != null) return Pair(full, design)
        }
        val full = normalizeMah(readSysfsLong("charge_full"))
        val design = normalizeMah(readSysfsLong("charge_full_design"))
            ?: readDesignFromPowerProfile(context)
        return Pair(full, design)
    }

    @SuppressLint("PrivateApi")
    private fun readDesignFromPowerProfile(context: Context): Int? {
        return try {
            val c = Class.forName("com.android.internal.os.PowerProfile")
            val inst = c.getConstructor(Context::class.java).newInstance(context)
            val cap = c.getMethod("getBatteryCapacity").invoke(inst) as Double
            cap.roundToInt().takeIf { it > 0 }
        } catch (_: Throwable) {
            null
        }
    }

    private fun readScreenOnTimeSinceFullCharge(
        context: Context,
        intent: Intent?
    ): Pair<Long?, SotSource> {
        if (FullChargeTracker.isCurrentlyFullAndPlugged(intent)) {
            return Pair(0L, SotSource.FULL_CHARGE_TRACKED)
        }

        val now = System.currentTimeMillis()

        val trackedStartMs = FullChargeTracker.getLastFullChargeTimestamp(context)
        if (trackedStartMs > 0L && trackedStartMs <= now) {
            val sot = computeScreenOnTimeBetween(context, trackedStartMs, now)
            return Pair(sot ?: 0L, SotSource.FULL_CHARGE_TRACKED)
        }

        val sysResetMs = readSystemLastFullChargeTimestamp(context)
        if (sysResetMs != null && sysResetMs > 0L && sysResetMs <= now) {
            val sot = computeScreenOnTimeBetween(context, sysResetMs, now)
            if (sot != null) {
                return Pair(sot, SotSource.SYSTEM_LAST_CHARGE)
            }
        }

        val bootMs = (now - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
        val fallbackSot = computeScreenOnTimeBetween(context, bootMs, now)
        return Pair(fallbackSot, SotSource.WAITING_FULL_CHARGE)
    }

    @SuppressLint("PrivateApi")
    private fun readSystemLastFullChargeTimestamp(context: Context): Long? {
        runCatching {
            val mgr = context.getSystemService("batterystats") ?: return@runCatching null
            val stats = mgr.javaClass.getMethod("getBatteryUsageStats").invoke(mgr) ?: return@runCatching null
            extractStatsStartTimestamp(stats)
        }.getOrNull()?.let { return it }

        return runCatching {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java).invoke(null, "batterystats") as? IBinder
                ?: return@runCatching null
            val stub = Class.forName("com.android.internal.app.IBatteryStats\$Stub")
            val svc = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
                ?: return@runCatching null

            val qBuilderClass = Class.forName("android.os.BatteryUsageStatsQuery\$Builder")
            val qBuilder = qBuilderClass.getDeclaredConstructor().newInstance()
            val query = qBuilderClass.getMethod("build").invoke(qBuilder)
            val m = svc.javaClass.methods.firstOrNull {
                it.name == "getBatteryUsageStats" && it.parameterCount == 1
            } ?: return@runCatching null

            val list = m.invoke(svc, listOf(query)) as? List<*> ?: return@runCatching null
            val stats = list.firstOrNull() ?: return@runCatching null
            extractStatsStartTimestamp(stats)
        }.getOrNull()
    }

    private fun extractStatsStartTimestamp(usageStats: Any): Long? {
        val ts = runCatching {
            usageStats.javaClass.getMethod("getStatsStartTimestamp").invoke(usageStats) as? Long
        }.getOrNull() ?: return null
        val now = System.currentTimeMillis()
        val maxAgeMs = 14L * 24L * 60L * 60L * 1000L
        return ts.takeIf { it > 0L && it <= now && (now - it) <= maxAgeMs }
    }

    private fun computeScreenOnTimeBetween(context: Context, startMs: Long, now: Long): Long? {
        if (startMs <= 0L || now <= startMs) return 0L
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                ?: return null

            val lookbackStart = (startMs - 6L * 60L * 60L * 1000L).coerceAtLeast(0L)
            val events = usm.queryEvents(lookbackStart, now) ?: return null
            val event = UsageEvents.Event()

            var isScreenOn = false
            var sawEventBeforeStart = false
            var sawEventAfterStart = false
            var segmentStart = startMs
            var totalMs = 0L

            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                val ts = event.timeStamp
                val type = event.eventType

                if (type != UsageEvents.Event.SCREEN_INTERACTIVE &&
                    type != UsageEvents.Event.SCREEN_NON_INTERACTIVE &&
                    type != EVENT_DEVICE_SHUTDOWN
                ) {
                    continue
                }

                if (ts <= startMs) {
                    sawEventBeforeStart = true
                    isScreenOn = (type == UsageEvents.Event.SCREEN_INTERACTIVE)
                    segmentStart = startMs
                } else {
                    if (!sawEventAfterStart) {
                        sawEventAfterStart = true
                        if (!sawEventBeforeStart &&
                            (type == UsageEvents.Event.SCREEN_NON_INTERACTIVE || type == EVENT_DEVICE_SHUTDOWN)
                        ) {
                            isScreenOn = true
                            segmentStart = startMs
                        }
                    }

                    when (type) {
                        UsageEvents.Event.SCREEN_INTERACTIVE -> {
                            if (!isScreenOn) {
                                isScreenOn = true
                                segmentStart = ts
                            }
                        }
                        UsageEvents.Event.SCREEN_NON_INTERACTIVE, EVENT_DEVICE_SHUTDOWN -> {
                            if (isScreenOn) {
                                totalMs += (ts - segmentStart).coerceAtLeast(0L)
                                isScreenOn = false
                            }
                        }
                    }
                }
            }

            if (!sawEventAfterStart && !sawEventBeforeStart) {
                val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                if (pm?.isInteractive == true) {
                    totalMs += (now - startMs).coerceAtLeast(0L)
                }
            } else if (isScreenOn) {
                totalMs += (now - segmentStart).coerceAtLeast(0L)
            }

            totalMs.coerceAtLeast(0L)
        } catch (_: Throwable) {
            null
        }
    }

    fun formatDuration(ms: Long?): String {
        if (ms == null || ms < 0L) return "Okunamadı"
        val mins = ms / 60_000L
        val h = mins / 60L
        val m = mins % 60L
        return if (h > 0L) "${h} sa ${m} dk" else "${m} dk"
    }

    fun formatTemp(temp: Float?): String =
        temp?.let { String.format(Locale.getDefault(), "%.1f °C", it) } ?: "N/A"

    fun formatCapacity(real: Int?, design: Int?, health: Int?): String = when {
        real != null && design != null -> "$real / $design mAh (%${health ?: "--"})"
        real != null -> "$real mAh"
        else -> "N/A"
    }
}
