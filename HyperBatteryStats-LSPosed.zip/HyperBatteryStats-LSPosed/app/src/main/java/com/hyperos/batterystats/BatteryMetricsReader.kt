package com.hyperos.batterystats

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.IBinder
import de.robv.android.xposed.XposedBridge
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

data class BatterySnapshot(
    val temperatureC: Float?,
    val cycleCount: Int?,
    val realCapacityMah: Int?,
    val designCapacityMah: Int?,
    val healthPercent: Int?,
    val screenOnTimeMs: Long?
)

object BatteryMetricsReader {

    private val CHARGE_FULL_PATHS = listOf(
        "/sys/class/power_supply/battery/charge_full",
        "/sys/class/power_supply/bms/charge_full",
        "/sys/class/power_supply/maxfg/charge_full",
        "/sys/class/power_supply/qcom-battery/charge_full"
    )

    private val CHARGE_DESIGN_PATHS = listOf(
        "/sys/class/power_supply/battery/charge_full_design",
        "/sys/class/power_supply/bms/charge_full_design",
        "/sys/class/power_supply/maxfg/charge_full_design",
        "/sys/class/power_supply/qcom-battery/charge_full_design"
    )

    private val CYCLE_COUNT_PATHS = listOf(
        "/sys/class/power_supply/battery/cycle_count",
        "/sys/class/power_supply/bms/cycle_count",
        "/sys/class/power_supply/maxfg/cycle_count",
        "/sys/class/power_supply/qcom-battery/cycle_count"
    )

    private val TEMP_PATHS = listOf(
        "/sys/class/power_supply/battery/temp",
        "/sys/class/power_supply/bms/temp"
    )

    fun read(context: Context): BatterySnapshot {
        val batteryIntent = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )

        val tempC = readTemperature(batteryIntent)
        val cycles = readCycleCount(batteryIntent)
        val realMah = readCapacityMah(CHARGE_FULL_PATHS)
        val designMah = readCapacityMah(CHARGE_DESIGN_PATHS)
            ?: readDesignCapacityFromPowerProfile(context)

        val healthPct = if (realMah != null && designMah != null && designMah > 0) {
            ((realMah.toDouble() / designMah.toDouble()) * 100.0)
                .roundToInt()
                .coerceIn(1, 100)
        } else {
            null
        }

        val sotMs = readRealScreenOnTimeMs()

        return BatterySnapshot(
            temperatureC = tempC,
            cycleCount = cycles,
            realCapacityMah = realMah,
            designCapacityMah = designMah,
            healthPercent = healthPct,
            screenOnTimeMs = sotMs
        )
    }

    private fun readTemperature(intent: Intent?): Float? {
        val intentTemp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        if (intentTemp != null && intentTemp != Int.MIN_VALUE) {
            return intentTemp / 10f
        }
        val sysfsTemp = readFirstLong(TEMP_PATHS) ?: return null
        return sysfsTemp / 10f
    }

    private fun readCycleCount(intent: Intent?): Int? {
        val extraKey = "android.os.extra.CYCLE_COUNT"
        val intentCycles = intent?.getIntExtra(extraKey, -1) ?: -1
        if (intentCycles >= 0) return intentCycles
        return readFirstLong(CYCLE_COUNT_PATHS)?.toInt()
    }

    private fun readCapacityMah(paths: List<String>): Int? {
        val raw = readFirstLong(paths) ?: return null
        return when {
            raw > 100_000L -> (raw / 1000L).toInt()
            raw > 0L -> raw.toInt()
            else -> null
        }
    }

    private fun readFirstLong(paths: List<String>): Long? {
        for (path in paths) {
            try {
                val file = File(path)
                if (file.exists() && file.canRead()) {
                    val value = file.readText().trim().toLongOrNull()
                    if (value != null && value >= 0L) return value
                }
            } catch (_: Throwable) {
                // Erişim kısıtı varsa sonraki düğümü dene
            }
        }
        return null
    }

    @SuppressLint("PrivateApi")
    private fun readDesignCapacityFromPowerProfile(context: Context): Int? {
        return try {
            val clazz = Class.forName("com.android.internal.os.PowerProfile")
            val instance = clazz.getConstructor(Context::class.java).newInstance(context)
            val capacity = clazz.getMethod("getBatteryCapacity").invoke(instance) as Double
            capacity.roundToInt().takeIf { it > 0 }
        } catch (_: Throwable) {
            null
        }
    }

    @SuppressLint("PrivateApi")
    private fun readRealScreenOnTimeMs(): Long? {
        return try {
            val smClass = Class.forName("android.os.ServiceManager")
            val getService = smClass.getMethod("getService", String::class.java)
            val binder = getService.invoke(null, "batterystats") as? IBinder ?: return null

            val stubClass = Class.forName("com.android.internal.app.IBatteryStats\$Stub")
            val service = stubClass.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
                ?: return null

            val directMethod = service.javaClass.methods.firstOrNull {
                it.name.contains("ScreenOn", ignoreCase = true) && it.parameterCount == 0
            }
            if (directMethod != null) {
                val directVal = (directMethod.invoke(service) as? Number)?.toLong()
                if (directVal != null && directVal >= 0L) return directVal
            }

            val queryBuilderClass = Class.forName("android.os.BatteryUsageStatsQuery\$Builder")
            val queryBuilder = queryBuilderClass.getDeclaredConstructor().newInstance()
            val query = queryBuilderClass.getMethod("build").invoke(queryBuilder)

            val getStatsMethod = service.javaClass.methods.firstOrNull {
                it.name == "getBatteryUsageStats" && it.parameterCount == 1
            } ?: return null

            val statsList = getStatsMethod.invoke(service, listOf(query)) as? List<*>
            val usageStats = statsList?.firstOrNull() ?: return null

            val getAgg = usageStats.javaClass.getMethod(
                "getAggregateBatteryConsumer",
                Int::class.javaPrimitiveType
            )
            // AGGREGATE_BATTERY_CONSUMER_SCOPE_DEVICE = 0
            val deviceConsumer = getAgg.invoke(usageStats, 0) ?: return null
            val getUsageDuration = deviceConsumer.javaClass.getMethod(
                "getUsageDurationMillis",
                Int::class.javaPrimitiveType
            )
            // BatteryConsumer.POWER_COMPONENT_SCREEN = 0
            val screenMs = getUsageDuration.invoke(deviceConsumer, 0) as? Long
            screenMs?.takeIf { it >= 0L }
        } catch (t: Throwable) {
            XposedBridge.log("HyperBatteryStats: SoT okuma hatası -> ${t.message}")
            null
        }
    }

    fun formatDuration(ms: Long?): String {
        if (ms == null || ms < 0L) return "Okunamadı"
        val totalMinutes = ms / 60_000L
        val hours = totalMinutes / 60L
        val minutes = totalMinutes % 60L
        return if (hours > 0L) "${hours} sa ${minutes} dk" else "${minutes} dk"
    }

    fun formatSummary(snapshot: BatterySnapshot): String {
        val tempStr = snapshot.temperatureC?.let {
            String.format(Locale.getDefault(), "%.1f °C", it)
        } ?: "N/A"
        val cycleStr = snapshot.cycleCount?.let { "$it döngü" } ?: "N/A"
        val capStr = when {
            snapshot.realCapacityMah != null && snapshot.designCapacityMah != null ->
                "${snapshot.realCapacityMah} / ${snapshot.designCapacityMah} mAh (%${snapshot.healthPercent ?: "--"})"
            snapshot.realCapacityMah != null ->
                "${snapshot.realCapacityMah} mAh"
            else -> "N/A"
        }
        val sotStr = formatDuration(snapshot.screenOnTimeMs)

        return buildString {
            append("Ekran Süresi (SoT): $sotStr\n")
            append("Sıcaklık: $tempStr  |  Döngü: $cycleStr\n")
            append("Gerçek Kapasite: $capStr")
        }
    }
}
