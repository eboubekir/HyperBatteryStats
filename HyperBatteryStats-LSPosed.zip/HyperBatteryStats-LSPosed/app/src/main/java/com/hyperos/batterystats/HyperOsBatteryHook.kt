package com.hyperos.batterystats

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XC_MethodReplacement
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import org.luckypray.dexkit.DexKitBridge
import org.luckypray.dexkit.query.enums.StringMatchType
import java.lang.reflect.Proxy

class HyperOsBatteryHook : IXposedHookLoadPackage {

    companion object {
        private const val TARGET_PKG = "com.miui.securitycenter"
        private const val PREF_KEY = "hyperos4_live_battery_stats"
        private const val TAG = "HyperBatteryStats"
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != TARGET_PKG) return

        XposedBridge.log("$TAG: $TARGET_PKG yüklendi, hook'lar hazırlanıyor...")

        unlockHiddenBatteryFeaturesWithDexKit(lpparam)
        hookBatteryPreferenceFragments(lpparam.classLoader)
    }

    private fun unlockHiddenBatteryFeaturesWithDexKit(lpparam: XC_LoadPackage.LoadPackageParam) {
        val keywords = listOf(
            "support_battery_health",
            "battery_cycle",
            "charge_full",
            "screen_on_time",
            "battery_usage_screen"
        )

        try {
            System.loadLibrary("dexkit")
            DexKitBridge.create(lpparam.appInfo.sourceDir).use { bridge ->
                val hookedSignatures = mutableSetOf<String>()

                for (keyword in keywords) {
                    val foundMethods = bridge.findMethod {
                        matcher {
                            returnType = "boolean"
                            paramCount = 0
                            usingStrings(listOf(keyword), StringMatchType.Contains)
                        }
                    }

                    for (methodData in foundMethods) {
                        runCatching {
                            val method = methodData.getMethodInstance(lpparam.classLoader)
                            val sig = "${method.declaringClass.name}#${method.name}"
                            if (!hookedSignatures.add(sig)) return@runCatching

                            XposedBridge.hookMethod(method, XC_MethodReplacement.returnConstant(true))
                            XposedBridge.log("$TAG: Özellik kilidi açıldı ($keyword) -> $sig")
                        }
                    }
                }
            }
        } catch (t: Throwable) {
            XposedBridge.log("$TAG: DexKit taraması atlandı -> ${t.message}")
        }
    }

    private fun hookBatteryPreferenceFragments(classLoader: ClassLoader) {
        val candidateBaseFragments = listOf(
            "miuix.preference.PreferenceFragment",
            "androidx.preference.PreferenceFragmentCompat"
        )

        for (baseClassName in candidateBaseFragments) {
            val baseClass = XposedHelpers.findClassIfExists(baseClassName, classLoader) ?: continue

            XposedHelpers.findAndHookMethod(
                baseClass,
                "onResume",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val fragment = param.thisObject ?: return
                        val fqcn = fragment.javaClass.name.lowercase()

                        val isBatteryScreen = fqcn.contains("powercenter") && (
                            fqcn.contains("battery") ||
                            fqcn.contains("power") ||
                            fqcn.contains("charge") ||
                            fqcn.contains("health")
                        )
                        if (!isBatteryScreen) return

                        injectOrUpdateStatsPreference(fragment, classLoader)
                    }
                }
            )
        }
    }

    private fun injectOrUpdateStatsPreference(fragment: Any, classLoader: ClassLoader) {
        try {
            val context = XposedHelpers.callMethod(fragment, "getContext") as? Context ?: return
            val prefScreen = XposedHelpers.callMethod(fragment, "getPreferenceScreen") ?: return

            val snapshot = BatteryMetricsReader.read(context)
            val summaryText = BatteryMetricsReader.formatSummary(snapshot)

            val existing = XposedHelpers.callMethod(prefScreen, "findPreference", PREF_KEY)
            if (existing != null) {
                XposedHelpers.callMethod(existing, "setSummary", summaryText)
                return
            }

            val prefClass = XposedHelpers.findClassIfExists(
                "androidx.preference.Preference",
                classLoader
            ) ?: return
            val pref = XposedHelpers.newInstance(prefClass, context)

            XposedHelpers.callMethod(pref, "setKey", PREF_KEY)
            XposedHelpers.callMethod(pref, "setTitle", "Detaylı Pil İstatistikleri")
            XposedHelpers.callMethod(pref, "setSummary", summaryText)
            XposedHelpers.callMethod(pref, "setOrder", -100)

            attachClickRefreshListener(pref, context, classLoader)

            XposedHelpers.callMethod(prefScreen, "addPreference", pref)
            XposedBridge.log("$TAG: Kart eklendi -> ${fragment.javaClass.simpleName}")
        } catch (t: Throwable) {
            XposedBridge.log("$TAG: Arayüz enjeksiyon hatası -> ${t.message}")
        }
    }

    private fun attachClickRefreshListener(pref: Any, context: Context, classLoader: ClassLoader) {
        try {
            val listenerInterface = XposedHelpers.findClassIfExists(
                "androidx.preference.Preference\$OnPreferenceClickListener",
                classLoader
            ) ?: return

            val proxy = Proxy.newProxyInstance(
                classLoader,
                arrayOf(listenerInterface)
            ) { _, method, _ ->
                if (method.name == "onPreferenceClick") {
                    val fresh = BatteryMetricsReader.read(context)
                    XposedHelpers.callMethod(
                        pref,
                        "setSummary",
                        BatteryMetricsReader.formatSummary(fresh)
                    )
                    true
                } else {
                    false
                }
            }

            XposedHelpers.callMethod(pref, "setOnPreferenceClickListener", proxy)
        } catch (_: Throwable) {
            // Tıklama yenileme eklenemese bile kart görüntülenir
        }
    }
}
