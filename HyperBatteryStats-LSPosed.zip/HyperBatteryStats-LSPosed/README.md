# HyperOS 4 Pil İstatistikleri (LSPosed Modülü)

Bu proje, **HyperOS 4** pil ayarları sayfasına canlı olarak **Ekran Süresi (SoT)**, **Pil Sıcaklığı**, **Şarj Döngüsü** ve **Gerçek Kapasite / Pil Sağlığı** bilgilerini ekleyen hazır LSPosed modülüdür.

## Bilgisayara Hiç Program Kurmadan APK Oluşturma (GitHub ile - 2 Dakika)

1. [GitHub.com](https://github.com) üzerinde ücretsiz bir hesap açın (varsa giriş yapın).
2. Sağ üstteki **+** simgesinden **New repository** seçin, adına `HyperBatteryStats` yazıp **Create repository** butonuna basın.
3. Açılan sayfada **uploading an existing file** bağlantısına tıklayın.
4. Bu ZIP arşivinin **içindeki tüm dosya ve klasörleri** (özellikle `.github` klasörü dahil) sürükleyip bırakın ve alttan **Commit changes** butonuna basın.
   > **Not:** Windows/Mac'te `.github` klasörü gizli görünebilir; klasörü açmadan önce "Gizli öğeleri göster" seçeneğini aktif edin.
5. Deponun üst menüsünden **Actions** sekmesine tıklayın.
6. **Build HyperBatteryStats APK** işleminin yeşil tik olmasını (~2 dakika) bekleyin.
7. İşleme tıklayıp en alttaki **Artifacts → HyperBatteryStats-HyperOS4-APK** bağlantısından APK dosyasını indirin.

## Telefona Kurulum

1. İndirdiğiniz ZIP içindeki `HyperBatteryStats-HyperOS4.apk` dosyasını telefona kurun.
2. **LSPosed Manager** uygulamasını açın → **Modüller** sekmesinden **HyperOS 4 Pil İstatistikleri** modülünü açın.
3. Kapsam (Scope) listesinde **Güvenlik (`com.miui.securitycenter`)** işaretli olsun.
4. Telefonu yeniden başlatın (veya Güvenlik uygulamasını zorla durdurun) ve **Ayarlar → Pil** ekranını açın.
