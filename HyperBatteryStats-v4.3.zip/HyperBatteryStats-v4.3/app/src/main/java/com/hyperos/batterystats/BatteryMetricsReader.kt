package com.hyperos.batterystats

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

data class BatterySnapshot(
    val temperatureC: Float?,
    val cycleCount: Int?,
    val realCapacityMah: Int?,
    val designCapacityMah: Int?,
    val healthPercent: Int?,
    val screenOnTimeMs: Long?,
    val elapsedSinceFullChargeMs: Long?
)

object BatteryMetricsReader {

    fun read(context: Context): BatterySnapshot {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val metrics = FullChargeTracker.syncAndGetMetrics(
            context = context,
            batteryIntent = intent,
            forceSave = false,
            explicitScreenState = null
        )

        val tempC = readTemperature(intent)
        val cycles = readCycleCount(intent)
        val (realMah, designMah) = readCapacities(context)

        val healthPct = if (realMah != null && designMah != null && designMah > 0) {
            ((realMah.toDouble() / designMah.toDouble()) * 100.0)
                .roundToInt()
                .coerceIn(1, 100)
        } else null

        return BatterySnapshot(
            temperatureC = tempC,
            cycleCount = cycles,
            realCapacityMah = realMah,
            designCapacityMah = designMah,
            healthPercent = healthPct,
            screenOnTimeMs = metrics.screenOnTimeMs,
            elapsedSinceFullChargeMs = metrics.elapsedSinceFullChargeMs
        )
    }

    private fun powerSupplyDirs(): List<File> {
        val preferred = listOf("bms", "battery", "maxfg", "qcom-battery", "mtk-gauge", "xm_bms")
        val root = File("/sys/class/power_supply")
        val all = root.listFiles()?.filter { it.isDirectory } ?: emptyList()
        val ordered = mutableListOf<File>()
        for (name in preferred) {
            all.firstOrNull { it.name.equals(name, ignoreCase = true) }?.let { ordered.add(it) }
        }
        for (dir in all) {
            if (ordered.none { it.absolutePath == dir.absolutePath }) ordered.add(dir)
        }
        val qcomDir = File("/sys/class/qcom-battery")
        if (qcomDir.isDirectory) ordered.add(qcomDir)
        return ordered
    }

    private fun readSysfsLong(fileName: String): Long? {
        for (dir in powerSupplyDirs()) {
            val v = readLongFile(File(dir, fileName))
            if (v != null) return v
        }
        return null
    }

    private fun readLongFile(file: File): Long? {
        return try {
            if (file.exists() && file.canRead()) {
                file.readText().trim().toLongOrNull()
            } else null
        } catch (_: Throwable) {
            null
        }
    }

    private fun normalizeMah(raw: Long?): Int? {
        if (raw == null || raw <= 0L) return null
        return if (raw > 100_000L) (raw / 1000L).toInt() else raw.toInt()
    }

    private fun readTemperature(intent: Intent?): Float? {
        val t = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        if (t != null && t != Int.MIN_VALUE && t > 0) return t / 10f
        val sys = readSysfsLong("temp") ?: return null
        return sys / 10f
    }

    private fun readCycleCount(intent: Intent?): Int? {
        val extra = intent?.getIntExtra("android.os.extra.CYCLE_COUNT", -1) ?: -1
        if (extra >= 0) return extra
        return readSysfsLong("cycle_count")?.takeIf { it >= 0L }?.toInt()
    }

    private fun readCapacities(context: Context): Pair<Int?, Int?> {
        for (dir in powerSupplyDirs()) {
            val full = normalizeMah(readLongFile(File(dir, "charge_full")))
            val design = normalizeMah(readLongFile(File(dir, "charge_full_design")))
            if (full != null && design != null) return Pair(full, design)
        }
        val full = normalizeMah(readSysfsLong("charge_full"))
        val design = normalizeMah(readSysfsLong("charge_full_design"))
            ?: readDesignFromPowerProfile(context)
        return Pair(full, design)
    }

    @SuppressLint("PrivateApi")
    private fun readDesignFromPowerProfile(context: Context): Int? {
        return try {
            val c = Class.forName("com.android.internal.os.PowerProfile")
            val inst = c.getConstructor(Context::class.java).newInstance(context)
            val cap = c.getMethod("getBatteryCapacity").invoke(inst) as Double
            cap.roundToInt().takeIf { it > 0 }
        } catch (_: Throwable) {
            null
        }
    }

    fun formatDuration(ms: Long?): String {
        if (ms == null || ms < 0L) return "Okunamadı"
        val mins = ms / 60_000L
        val h = mins / 60L
        val m = mins % 60L
        return if (h > 0L) "${h} sa ${m} dk" else "${m} dk"
    }

    fun formatElapsedSinceFullCharge(ms: Long?): String {
        if (ms == null || ms < 0L) return "Okunamadı"
        val totalMins = ms / 60_000L
        val days = totalMins / (24L * 60L)
        val hours = (totalMins % (24L * 60L)) / 60L
        val mins = totalMins % 60L
        return when {
            days > 0L && hours > 0L -> "${days} gün ${hours} sa"
            days > 0L && mins > 0L -> "${days} gün ${mins} dk"
            days > 0L -> "${days} gün"
            hours > 0L -> "${hours} sa ${mins} dk"
            else -> "${mins} dk"
        }
    }

    fun formatTemp(temp: Float?): String =
        temp?.let { String.format(Locale.getDefault(), "%.1f °C", it) } ?: "N/A"

    fun formatCapacity(real: Int?, design: Int?, health: Int?): String = when {
        real != null && design != null -> "$real / $design mAh (%${health ?: "--"})"
        real != null -> "$real mAh"
        else -> "N/A"
    }
}
