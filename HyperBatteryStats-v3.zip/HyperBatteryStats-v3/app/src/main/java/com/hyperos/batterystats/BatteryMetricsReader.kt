package com.hyperos.batterystats

import android.annotation.SuppressLint
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.IBinder
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

data class BatterySnapshot(
    val temperatureC: Float?,
    val cycleCount: Int?,
    val realCapacityMah: Int?,
    val designCapacityMah: Int?,
    val healthPercent: Int?,
    val screenOnTimeMs: Long?,
    val sotIs24hFallback: Boolean,
    val powerWatts: Float?,
    val isCharging: Boolean
)

object BatteryMetricsReader {

    fun read(context: Context): BatterySnapshot {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val tempC = readTemperature(intent)
        val cycles = readCycleCount(intent)
        val (realMah, designMah) = readCapacities(context)

        val healthPct = if (realMah != null && designMah != null && designMah > 0) {
            ((realMah.toDouble() / designMah.toDouble()) * 100.0)
                .roundToInt()
                .coerceIn(1, 100)
        } else null

        val (sotMs, is24h) = readScreenOnTime(context)
        val watts = readPowerWatts(context, intent)

        return BatterySnapshot(
            temperatureC = tempC,
            cycleCount = cycles,
            realCapacityMah = realMah,
            designCapacityMah = designMah,
            healthPercent = healthPct,
            screenOnTimeMs = sotMs,
            sotIs24hFallback = is24h,
            powerWatts = watts,
            isCharging = isCharging
        )
    }

    private fun powerSupplyDirs(): List<File> {
        val preferred = listOf("bms", "battery", "maxfg", "qcom-battery", "mtk-gauge", "xm_bms")
        val root = File("/sys/class/power_supply")
        val all = root.listFiles()?.filter { it.isDirectory } ?: emptyList()
        val ordered = mutableListOf<File>()
        for (name in preferred) {
            all.firstOrNull { it.name.equals(name, ignoreCase = true) }?.let { ordered.add(it) }
        }
        for (dir in all) {
            if (ordered.none { it.absolutePath == dir.absolutePath }) ordered.add(dir)
        }
        val qcomDir = File("/sys/class/qcom-battery")
        if (qcomDir.isDirectory) ordered.add(qcomDir)
        return ordered
    }

    private fun readSysfsLong(fileName: String): Long? {
        for (dir in powerSupplyDirs()) {
            val v = readLongFile(File(dir, fileName))
            if (v != null) return v
        }
        return null
    }

    private fun readLongFile(file: File): Long? {
        return try {
            if (file.exists() && file.canRead()) {
                file.readText().trim().toLongOrNull()
            } else null
        } catch (_: Throwable) {
            null
        }
    }

    private fun normalizeMah(raw: Long?): Int? {
        if (raw == null || raw <= 0L) return null
        return if (raw > 100_000L) (raw / 1000L).toInt() else raw.toInt()
    }

    private fun readTemperature(intent: Intent?): Float? {
        val t = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        if (t != null && t != Int.MIN_VALUE && t > 0) return t / 10f
        val sys = readSysfsLong("temp") ?: return null
        return sys / 10f
    }

    private fun readCycleCount(intent: Intent?): Int? {
        val extra = intent?.getIntExtra("android.os.extra.CYCLE_COUNT", -1) ?: -1
        if (extra >= 0) return extra
        return readSysfsLong("cycle_count")?.takeIf { it >= 0L }?.toInt()
    }

    private fun readCapacities(context: Context): Pair<Int?, Int?> {
        for (dir in powerSupplyDirs()) {
            val full = normalizeMah(readLongFile(File(dir, "charge_full")))
            val design = normalizeMah(readLongFile(File(dir, "charge_full_design")))
            if (full != null && design != null) return Pair(full, design)
        }
        val full = normalizeMah(readSysfsLong("charge_full"))
        val design = normalizeMah(readSysfsLong("charge_full_design"))
            ?: readDesignFromPowerProfile(context)
        return Pair(full, design)
    }

    @SuppressLint("PrivateApi")
    private fun readDesignFromPowerProfile(context: Context): Int? {
        return try {
            val c = Class.forName("com.android.internal.os.PowerProfile")
            val inst = c.getConstructor(Context::class.java).newInstance(context)
            val cap = c.getMethod("getBatteryCapacity").invoke(inst) as Double
            cap.roundToInt().takeIf { it > 0 }
        } catch (_: Throwable) {
            null
        }
    }

    private fun readPowerWatts(context: Context, intent: Intent?): Float? {
        return try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager ?: return null
            val rawCur = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            val voltMv = intent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
            if (rawCur == Int.MIN_VALUE || rawCur == 0 || voltMv <= 0) return null
            val curMa = if (abs(rawCur) > 20_000) rawCur / 1000.0 else rawCur.toDouble()
            val watts = abs((voltMv / 1000.0) * (curMa / 1000.0))
            watts.toFloat()
        } catch (_: Throwable) {
            null
        }
    }

    private fun readScreenOnTime(context: Context): Pair<Long?, Boolean> {
        readSotFromBatteryStatsManager(context)?.let { return Pair(it, false) }
        readSotFromIBatteryStats()?.let { return Pair(it, false) }
        readSotFromUsageStats24h(context)?.let { return Pair(it, true) }
        return Pair(null, false)
    }

    @SuppressLint("PrivateApi")
    private fun readSotFromBatteryStatsManager(context: Context): Long? {
        return try {
            val mgr = context.getSystemService("batterystats") ?: return null
            val usageStats = mgr.javaClass.getMethod("getBatteryUsageStats").invoke(mgr) ?: return null
            extractScreenDurationFromUsageStats(usageStats)
        } catch (_: Throwable) {
            null
        }
    }

    @SuppressLint("PrivateApi")
    private fun readSotFromIBatteryStats(): Long? {
        return try {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java).invoke(null, "batterystats") as? IBinder
                ?: return null
            val stub = Class.forName("com.android.internal.app.IBatteryStats\$Stub")
            val svc = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder) ?: return null

            val qBuilderClass = Class.forName("android.os.BatteryUsageStatsQuery\$Builder")
            val qBuilder = qBuilderClass.getDeclaredConstructor().newInstance()
            val query = qBuilderClass.getMethod("build").invoke(qBuilder)
            val m = svc.javaClass.methods.firstOrNull {
                it.name == "getBatteryUsageStats" && it.parameterCount == 1
            } ?: return null
            val list = m.invoke(svc, listOf(query)) as? List<*> ?: return null
            val usageStats = list.firstOrNull() ?: return null
            extractScreenDurationFromUsageStats(usageStats)
        } catch (_: Throwable) {
            null
        }
    }

    private fun extractScreenDurationFromUsageStats(usageStats: Any): Long? {
        return try {
            val getAgg = usageStats.javaClass.getMethod(
                "getAggregateBatteryConsumer",
                Int::class.javaPrimitiveType
            )
            val device = getAgg.invoke(usageStats, 0) ?: return null
            val getDur = device.javaClass.getMethod(
                "getUsageDurationMillis",
                Int::class.javaPrimitiveType
            )
            val ms = getDur.invoke(device, 0) as? Long
            ms?.takeIf { it > 0L }
        } catch (_: Throwable) {
            null
        }
    }

    private fun readSotFromUsageStats24h(context: Context): Long? {
        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                ?: return null
            val now = System.currentTimeMillis()
            val start = now - 24L * 60L * 60L * 1000L
            val events = usm.queryEvents(start, now) ?: return null
            val event = UsageEvents.Event()
            var totalMs = 0L
            var screenOnAt = -1L
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                when (event.eventType) {
                    UsageEvents.Event.SCREEN_INTERACTIVE -> {
                        if (screenOnAt < 0L) screenOnAt = event.timeStamp
                    }
                    UsageEvents.Event.SCREEN_NON_INTERACTIVE -> {
                        if (screenOnAt >= 0L) {
                            totalMs += (event.timeStamp - screenOnAt).coerceAtLeast(0L)
                            screenOnAt = -1L
                        }
                    }
                }
            }
            if (screenOnAt >= 0L) {
                totalMs += (now - screenOnAt).coerceAtLeast(0L)
            }
            totalMs.takeIf { it >= 0L }
        } catch (_: Throwable) {
            null
        }
    }

    fun formatDuration(ms: Long?): String {
        if (ms == null || ms < 0L) return "Okunamadı"
        val mins = ms / 60_000L
        val h = mins / 60L
        val m = mins % 60L
        return if (h > 0L) "${h} sa ${m} dk" else "${m} dk"
    }

    fun formatTemp(temp: Float?): String =
        temp?.let { String.format(Locale.getDefault(), "%.1f °C", it) } ?: "N/A"

    fun formatPower(watts: Float?, isCharging: Boolean): String {
        if (watts == null) return "N/A"
        val sign = if (isCharging) "+" else "-"
        return String.format(Locale.getDefault(), "%s%.1f W", sign, watts)
    }

    fun formatCapacity(real: Int?, design: Int?, health: Int?): String = when {
        real != null && design != null -> "$real / $design mAh (%${health ?: "--"})"
        real != null -> "$real mAh"
        else -> "N/A"
    }
}
